<?php 
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardFilesAttributesController extends Concrete5_Controller_Dashboard_Files_Attributes {

	
}