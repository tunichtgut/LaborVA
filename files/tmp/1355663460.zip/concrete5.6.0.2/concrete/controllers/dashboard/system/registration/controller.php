<?php 
defined('C5_EXECUTE') or die("Access Denied.");
Loader::controller('/dashboard/base');

class DashboardSystemRegistrationController extends Concrete5_Controller_Dashboard_System_Registration {}