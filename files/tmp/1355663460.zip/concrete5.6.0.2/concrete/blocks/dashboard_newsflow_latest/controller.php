<?php 
	defined('C5_EXECUTE') or die("Access Denied.");
	
	class DashboardNewsflowLatestBlockController extends Concrete5_Controller_Block_DashboardNewsflowLatest {


	}