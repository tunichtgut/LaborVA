<?php 

	defined('C5_EXECUTE') or die("Access Denied.");
	class PageListBlockController extends Concrete5_Controller_Block_PageList {
	
	}
