<?php 
defined('C5_EXECUTE') or die("Access Denied.");
Loader::model("collection_types");

$this->inc('page_list_form.php');

?>

